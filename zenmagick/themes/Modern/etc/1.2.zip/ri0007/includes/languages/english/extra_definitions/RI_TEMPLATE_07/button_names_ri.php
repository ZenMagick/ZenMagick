<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: button_names.php 5410 2006-12-27 03:56:46Z drbyte $
 */


/**
 * define the button images used in the project
 */



define('BUTTON_IMAGE_MORE_INFO', 'button_more_info.gif');
define('UTTON_MORE_INFO_ALT', 'More Info');
?>