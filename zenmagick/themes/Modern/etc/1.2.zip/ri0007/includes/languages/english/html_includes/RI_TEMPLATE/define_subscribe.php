<h1>Newsletter Subscription</h1>
<p>Thank you for taking a moment to subscribe to our Newsletter.</p>
<p>
You'll receive notices of newly available products, special offers, 
and news of upcoming showings.
</p>
