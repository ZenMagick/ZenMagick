
<p>
We're sorry to hear that you wish to unsubscribe from our newsletter.
If you have concerns about your privacy, please see our 
<a href="<?php echo zen_href_link(FILENAME_PRIVACY,'','NONSSL'); ?>"><span class="pseudolink">privacy notice</span></a>.
</p>

<p>
Subscribers to our newsletter are kept notified of new products, price reductions,
and site news.
</p>

<p>
If you still do not wish to receive your newsletter, enter your email and click the button below.
You may be prompted to log in first.
</p>

