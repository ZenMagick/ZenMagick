<style type="text/css">
.itemImage {
text-align:center;
border:1px solid #CCCCCC;
width:<?php echo IMAGE_PRODUCT_LISTING_WIDTH;?>px;
height:<?php echo IMAGE_PRODUCT_LISTING_HEIGHT;?>px;
}
.itemContainer{width:<?php echo IMAGE_PRODUCT_LISTING_WIDTH;?>px;}
</style>