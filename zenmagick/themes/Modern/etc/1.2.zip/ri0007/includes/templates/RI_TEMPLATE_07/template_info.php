<?php
/**
 * Template Information File
 *
 * @package templateSystem
 * @copyright Copyright 2003-2005 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: template_info.php 2306 2009-10-21 14:34:28Z tnmp83$
 */
$template_name = 'RI TEMPLATE 07';
$template_version = 'Version 1.0';
$template_author = 'RubikIntegration.com team';
$template_description = 'RubikIntegration007 template proudly brought to you by RubikIntegration.com team';
$template_screenshot = 'ri_template.jpg';
?>