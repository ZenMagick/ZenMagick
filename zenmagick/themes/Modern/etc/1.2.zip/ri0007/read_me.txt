Author: RubikIntegration.com team

Installation:
1. Upload files and folders and corresponding locations
Since this template makes use of Single Listing Module, it overwrites 4 files in includes/modules/pages. Please back up first

2. To save your time, we have included an sql file which you can run via admin-tools-sql patch, this will save your configuration time

3. Enable your new template

License: GPL 2.0
Feel free to remove the link back to our site at the footer of the template. We do appreciate it if you can leave it there, however.

In case you want to remove the link but still want to show your appreciation, please consider buying us a cup of coffee. Any amount will help with future free modules/addons/templates. Please send your donation to thankyou@rubikintegration.com