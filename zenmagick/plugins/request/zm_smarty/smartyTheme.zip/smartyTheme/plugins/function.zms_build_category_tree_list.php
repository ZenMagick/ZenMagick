<?php
/**
 * Smarty plugin
 * @package Smarty
 * @subpackage plugins
 */


/**
 * Smarty {zms_build_category_tree_list} function plugin
 *
 * Type:     function<br>
 * Name:     zms_build_category_tree_list<br>
 * Purpose:  Wrapper
 * @author   DerManoMann
 * @param array
 * @param Smarty
 * @return string
 */
function smarty_function_zms_build_category_tree_list($params, &$smarty) {
    return zm_build_category_tree_list($params['categories'], _zms_ad($params, 'showProductCount', zm_setting('isShowCategoryProductCount')), 
      _zms_ad($params, 'useCategoryPage', zm_setting('isUseCategoryPage')), _zms_ad($params, 'activeParent', false), _zms_ad($params, 'root', true));
}

/* vim: set expandtab: */

?>
