<?php
/**
 * Smarty plugin
 * @package Smarty
 * @subpackage plugins
 */


/**
 * Smarty {zms_onload} function plugin
 *
 * Type:     function<br>
 * Name:     zms_onload<br>
 * Purpose:  Wrapper
 * @author   DerManoMann
 * @param array
 * @param Smarty
 * @return string
 */
function smarty_function_zms_onload($params, &$smarty) {
    return zm_onload(_zms_ad($params, 'page', null), false);
}

/* vim: set expandtab: */

?>
